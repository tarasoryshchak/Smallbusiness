﻿using System.Collections.Generic;
using System.Linq;
using DAL;
using DAL.Models;

namespace BLL.Services
{
    public class ProductService
    {
        private readonly AppDbContext _context;

        public ProductService(AppDbContext context)
        {
            _context = context;
        }

        public List<Product> GetAllProducts()
        {
            return _context.Products.ToList();
        }

        public void AddProduct(Product product)
        {
            _context.Products.Add(product);
            _context.SaveChanges();
        }

        public void UpdateProduct(Product product)
        {
            var existingProduct = _context.Products.Find(product.ProductId);
            if (existingProduct != null)
            {
                existingProduct.Quantity = product.Quantity;
                existingProduct.Price = product.Price;
                _context.SaveChanges();
            }
        }
    }
}
