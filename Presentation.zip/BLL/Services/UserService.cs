﻿using System.Collections.Generic;
using System.Linq;
using DAL;
using DAL.Models;

namespace BLL.Services
{
    public class UserService
    {
        private readonly AppDbContext _context;

        public UserService(AppDbContext context)
        {
            _context = context;
        }

        public List<User> GetAllUsers()
        {
            return _context.Users.ToList();
        }

        public void AddUser(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
        }

        public void DeleteUser(int userId)
        {
            var user = _context.Users.Find(userId);
            if (user != null)
            {
                _context.Users.Remove(user);
                _context.SaveChanges();
            }
        }

        public void AssignRole(int userId, string role)
        {
            var user = _context.Users.Find(userId);
            if (user != null)
            {
                user.Role = role;
                _context.SaveChanges();
            }
        }
    }
}
