﻿using Microsoft.EntityFrameworkCore;
using DAL.Models;

namespace DAL
{
    public class AppDbContext : DbContext
    {
        // Визначення таблиць
        public DbSet<Order> Orders { get; set; } = null!;
        public DbSet<Product> Products { get; set; } = null!;
        public DbSet<Customer> Customers { get; set; } = null!;
        public DbSet<User> Users { get; set; } = null!;

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        // Налаштування DbContext
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseInMemoryDatabase("BusinessManagementDb");
            }
        }

        // Налаштування моделі
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Конфігурація таблиці Customers
            modelBuilder.Entity<Customer>(entity =>
            {
                entity.ToTable("Customers");
                entity.HasKey(c => c.CustomerId);
                entity.Property(c => c.Name)
                      .IsRequired()
                      .HasMaxLength(100);
                entity.Property(c => c.Purchases).IsRequired();
                entity.Property(c => c.Discount)
                      .HasMaxLength(10); // Наприклад, "10%" або "5%"
            });

            // Конфігурація таблиці Products
            modelBuilder.Entity<Product>(entity =>
            {
                entity.ToTable("Products");
                entity.HasKey(p => p.ProductId);
                entity.Property(p => p.Name)
                      .IsRequired()
                      .HasMaxLength(100);
                entity.Property(p => p.Price).IsRequired();
                entity.Property(p => p.StockStatus)
                      .IsRequired()
                      .HasMaxLength(20); // Наприклад, "In Stock" або "Out of Stock"
            });

            // Конфігурація таблиці Orders
            modelBuilder.Entity<Order>(entity =>
            {
                entity.ToTable("Orders");
                entity.HasKey(o => o.OrderId);
                entity.Property(o => o.ClientName)
                      .IsRequired()
                      .HasMaxLength(100);
                entity.Property(o => o.OrderStatus)
                      .IsRequired()
                      .HasMaxLength(50);
                entity.Property(o => o.TotalPrice).IsRequired();
                entity.Property(o => o.PurchaseDate).IsRequired();
            });

            // Конфігурація таблиці Users
            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("Users");
                entity.HasKey(u => u.UserId);
                entity.Property(u => u.Username)
                      .IsRequired()
                      .HasMaxLength(50);
                entity.Property(u => u.Role)
                      .IsRequired()
                      .HasMaxLength(50); // Наприклад, "Адміністратор", "Менеджер"
            });
        }
    }
}
