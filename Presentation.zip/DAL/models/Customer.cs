﻿namespace DAL.Models
{
    public class Customer
    {
        public int CustomerId { get; set; } // Ідентифікатор клієнта
        public string Name { get; set; }    // Ім'я клієнта
        public int Purchases { get; set; } // Кількість покупок
        public string Discount { get; set; } // Знижка клієнта
    }
}
