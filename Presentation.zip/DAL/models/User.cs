﻿namespace DAL.Models
{
    public class User
    {
        public int UserId { get; set; } // Ідентифікатор користувача
        public string Name { get; set; } // Ім'я користувача
        public string Role { get; set; } // Роль (Адміністратор, Менеджер, Бухгалтер)
    }
}
