﻿namespace DAL.Models
{
    public class Product
    {
        public int ProductId { get; set; } // Ідентифікатор товару
        public string Name { get; set; } // Назва товару
        public int Quantity { get; set; } // Кількість товару
        public decimal Price { get; set; } // Ціна товару
        public string StockStatus { get; set; } // Статус запасу (В наявності, Закінчується)
    }
}
