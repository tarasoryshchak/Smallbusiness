﻿namespace DAL.Models
{
    public class Order
    {
        public int OrderId { get; set; } // Ідентифікатор замовлення
        public string CustomerName { get; set; } // Ім'я клієнта
        public string Status { get; set; } // Статус замовлення (Підтверджено, В дорозі, Виконано)
        public string Date { get; set; } // Дата створення замовлення
        public decimal Total { get; set; } // Загальна сума замовлення
    }
}
