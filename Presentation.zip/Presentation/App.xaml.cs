﻿using System.Windows;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using DAL;
using BLL.Services;

namespace Presentation
{
    public partial class App : Application
    {
        // Глобальний ServiceProvider для доступу до ін'єкцій залежностей
        public static ServiceProvider ServiceProvider { get; private set; } = null!;

        // Викликається під час старту програми
        protected override void OnStartup(StartupEventArgs e)
        {
            // Створення контейнера DI
            var services = new ServiceCollection();
            ConfigureServices(services);

            // Побудова ServiceProvider
            ServiceProvider = services.BuildServiceProvider();

            // Відображення головного вікна
            var mainWindow = ServiceProvider.GetService<MainWindow>();
            mainWindow?.Show();
        }

        // Метод для налаштування сервісів
        private void ConfigureServices(ServiceCollection services)
        {
            // Налаштування DbContext із використанням InMemoryDatabase
            services.AddDbContext<AppDbContext>(options =>
                options.UseInMemoryDatabase("BusinessManagementDb")); // Для тестів можна змінити на UseSqlServer()

            // Реєстрація сервісів рівня BLL
            services.AddScoped<OrderService>();
            services.AddScoped<ProductService>();
            services.AddScoped<CustomerService>();
            services.AddScoped<UserService>();

            // Реєстрація вікон Presentation рівня
            services.AddTransient<MainWindow>();
            services.AddTransient<SalesWindow>();
            services.AddTransient<FinanceWindow>();
            services.AddTransient<InventoryWindow>();
            services.AddTransient<ClientsWindow>();
            services.AddTransient<UsersWindow>();
        }
    }
}
