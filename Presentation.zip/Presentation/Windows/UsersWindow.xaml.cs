﻿using System.Collections.Generic;
using System.Windows;
using System.Linq;
using System.Windows.Controls;

namespace Presentation
{
    public partial class UsersWindow : Window
    {
        // Колекція для збереження користувачів
        public List<User> Users { get; set; }

        public UsersWindow()
        {
            InitializeComponent();
            Users = new List<User>
            {
                new User { UserId = 1, Name = "Іванов Іван", Role = "Адміністратор" },
                new User { UserId = 2, Name = "Петров Петро", Role = "Менеджер" },
                new User { UserId = 3, Name = "Оленко Олена", Role = "Бухгалтер" }
            };
            UsersGrid.ItemsSource = Users;
        }

        // Додавання нового користувача
        private void AddUser(object sender, RoutedEventArgs e)
        {
            // Перевірка введених даних
            if (string.IsNullOrWhiteSpace(UserNameTextBox.Text) || RoleComboBox.SelectedItem == null)
            {
                MessageBox.Show("Будь ласка, заповніть всі поля.");
                return;
            }

            // Створення нового користувача
            var newUser = new User
            {
                UserId = Users.Count + 1,
                Name = UserNameTextBox.Text,
                Role = ((ComboBoxItem)RoleComboBox.SelectedItem).Content.ToString()
            };

            // Додавання користувача до колекції
            Users.Add(newUser);

            // Очищення полів після додавання
            UserNameTextBox.Clear();
            RoleComboBox.SelectedIndex = -1;

            // Оновлення таблиці
            UsersGrid.Items.Refresh();
            MessageBox.Show("Користувача додано успішно!");
        }

        // Видалення вибраного користувача
        private void DeleteUser(object sender, RoutedEventArgs e)
        {
            if (UsersGrid.SelectedItem is User selectedUser)
            {
                Users.Remove(selectedUser);
                UsersGrid.Items.Refresh();
                MessageBox.Show($"Користувач \"{selectedUser.Name}\" видалений.");
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть користувача для видалення.");
            }
        }

        // Призначення ролі користувачу
        private void AssignRole(object sender, RoutedEventArgs e)
        {
            if (UsersGrid.SelectedItem is User selectedUser && RoleComboBox.SelectedItem != null)
            {
                selectedUser.Role = ((ComboBoxItem)RoleComboBox.SelectedItem).Content.ToString();
                UsersGrid.Items.Refresh();
                MessageBox.Show($"Роль користувача \"{selectedUser.Name}\" змінено на \"{selectedUser.Role}\".");
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть користувача та роль для призначення.");
            }
        }
    }

    // Клас для користувача
    public class User
    {
        public int UserId { get; set; }
        public string Name { get; set; }
        public string Role { get; set; }
    }
}
