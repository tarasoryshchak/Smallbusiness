﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace Presentation
{
    public partial class SalesWindow : Window
    {
        // Колекція для збереження замовлень
        public List<Order> Orders { get; set; }

        public SalesWindow()
        {
            InitializeComponent();
            Orders = new List<Order>
            {
                new Order { OrderId = 1, Customer = "Іванов", Status = "Підтверджено", Date = "01.12.2024", Total = 500 },
                new Order { OrderId = 2, Customer = "Петров", Status = "В дорозі", Date = "02.12.2024", Total = 750 }
            };
            OrdersGrid.ItemsSource = Orders;
        }

        // Додавання нового замовлення
        private void CreateOrder(object sender, RoutedEventArgs e)
        {
            // Перевірка введених даних
            if (string.IsNullOrWhiteSpace(CustomerTextBox.Text) ||
                OrderStatusComboBox.SelectedItem == null ||
                OrderDatePicker.SelectedDate == null ||
                string.IsNullOrWhiteSpace(TotalTextBox.Text))
            {
                MessageBox.Show("Будь ласка, заповніть всі поля.");
                return;
            }

            // Створення нового замовлення
            var newOrder = new Order
            {
                OrderId = Orders.Count + 1,
                Customer = CustomerTextBox.Text,
                Status = ((ComboBoxItem)OrderStatusComboBox.SelectedItem).Content.ToString(),
                Date = OrderDatePicker.SelectedDate.Value.ToString("dd.MM.yyyy"),
                Total = decimal.Parse(TotalTextBox.Text)
            };

            // Додавання замовлення до колекції
            Orders.Add(newOrder);

            // Очищення полів після додавання
            CustomerTextBox.Clear();
            OrderStatusComboBox.SelectedIndex = -1;
            OrderDatePicker.SelectedDate = null;
            TotalTextBox.Clear();

            OrdersGrid.Items.Refresh();
            MessageBox.Show("Замовлення додано успішно!");
        }

        // Оновлення статусу замовлення
        private void UpdateOrderStatus(object sender, RoutedEventArgs e)
        {
            if (OrdersGrid.SelectedItem is Order selectedOrder)
            {
                selectedOrder.Status = "Оновлено";  // Оновлення статусу
                OrdersGrid.Items.Refresh();
                MessageBox.Show($"Статус замовлення \"{selectedOrder.OrderId}\" оновлено.");
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть замовлення для оновлення статусу.");
            }
        }

        // Видалення замовлення
        private void DeleteOrder(object sender, RoutedEventArgs e)
        {
            if (OrdersGrid.SelectedItem is Order selectedOrder)
            {
                Orders.Remove(selectedOrder);
                OrdersGrid.Items.Refresh();
                MessageBox.Show($"Замовлення \"{selectedOrder.OrderId}\" видалено.");
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть замовлення для видалення.");
            }
        }
    }

    // Клас для замовлення
    public class Order
    {
        public int OrderId { get; set; }
        public string Customer { get; set; }
        public string Status { get; set; }
        public string Date { get; set; }
        public decimal Total { get; set; }
    }
}
