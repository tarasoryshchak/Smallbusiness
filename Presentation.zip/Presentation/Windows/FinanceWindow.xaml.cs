﻿using System.Windows;
using System.Windows.Controls;

namespace Presentation
{
    public partial class FinanceWindow : Window
    {
        // Вибраний період
        private string selectedPeriod;

        public FinanceWindow()
        {
            InitializeComponent();
        }

        // Обробка натискання на кнопки для вибору періоду
        private void SelectPeriod(object sender, RoutedEventArgs e)
        {
            // Визначаємо, який період вибрано
            Button button = sender as Button;
            selectedPeriod = button.Content.ToString();

            // Виводимо повідомлення про вибір
            MessageBox.Show($"Вибрано період: {selectedPeriod}");
        }

        // Генерація фінансового звіту в залежності від вибраного періоду
        private void GenerateReport(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(selectedPeriod))
            {
                MessageBox.Show("Будь ласка, виберіть період для генерування звіту.");
                return;
            }

            // Створюємо звіт на основі вибраного періоду
            string report = $"Фінансовий звіт за {selectedPeriod}:\n";
            report += "------------------------\n";
            report += $"Дохід: 10000 грн\n";
            report += $"Витрати: 5000 грн\n";
            report += $"Чистий прибуток: 5000 грн\n";

            // Виводимо звіт на екран
            ReportTextBlock.Text = report;
        }
    }
}
