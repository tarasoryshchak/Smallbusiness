﻿using BLL.Services;
using DAL;
using DAL.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;

namespace Presentation
{
    public partial class ClientsWindow : Window
    {
        private readonly CustomerService _customerService;

        public ObservableCollection<Customer> Customers { get; set; }

        public ClientsWindow()
        {
            InitializeComponent();

            // Налаштування контексту
            var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();
            optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=MyDatabase;Trusted_Connection=True;");
            var context = new AppDbContext(optionsBuilder.Options);

            _customerService = new CustomerService(context);

            // Завантаження даних із бази
            Customers = new ObservableCollection<Customer>(_customerService.GetAllCustomers());
            ClientsGrid.ItemsSource = Customers;
        }

        private void AddClient(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ClientNameTextBox.Text) ||
                string.IsNullOrWhiteSpace(PurchasesTextBox.Text) ||
                string.IsNullOrWhiteSpace(DiscountTextBox.Text))
            {
                MessageBox.Show("Будь ласка, заповніть всі поля для додавання клієнта.");
                return;
            }

            var newCustomer = new Customer
            {
                Name = ClientNameTextBox.Text,
                Purchases = int.Parse(PurchasesTextBox.Text),
                Discount = DiscountTextBox.Text
            };

            _customerService.AddCustomer(newCustomer);

            // Оновлення таблиці
            Customers.Add(newCustomer);

            ClientNameTextBox.Clear();
            PurchasesTextBox.Clear();
            DiscountTextBox.Clear();

            MessageBox.Show("Клієнт успішно доданий!");
        }
    }
}
