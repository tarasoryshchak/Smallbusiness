﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace Presentation
{
    public partial class InventoryWindow : Window
    {
        // Колекція для збереження продуктів
        public ObservableCollection<Product> Products { get; set; }

        public InventoryWindow()
        {
            InitializeComponent();
            // Ініціалізуємо колекцію продуктів
            Products = new ObservableCollection<Product>
            {
                new Product { ProductId = 1, Name = "Ноутбук", Quantity = 10, Price = 15000, StockStatus = "В наявності" },
                new Product { ProductId = 2, Name = "Смартфон", Quantity = 5, Price = 20000, StockStatus = "Закінчується" },
            };
            ProductsGrid.ItemsSource = Products;
        }

        // Додавання нового продукту
        private void AddProduct(object sender, RoutedEventArgs e)
        {
            // Перевірка, чи вибрано товар і заповнені поля
            if (ProductTypeComboBox.SelectedItem == null ||
                string.IsNullOrWhiteSpace(QuantityTextBox.Text) ||
                string.IsNullOrWhiteSpace(PriceTextBox.Text) ||
                StockStatusComboBox.SelectedItem == null)
            {
                MessageBox.Show("Будь ласка, заповніть всі поля для додавання товару.");
                return;
            }

            // Створення нового продукту
            var newProduct = new Product
            {
                ProductId = Products.Count + 1,
                Name = ((ComboBoxItem)ProductTypeComboBox.SelectedItem).Content.ToString(),
                Quantity = int.Parse(QuantityTextBox.Text),
                Price = decimal.Parse(PriceTextBox.Text),
                StockStatus = ((ComboBoxItem)StockStatusComboBox.SelectedItem).Content.ToString()
            };

            // Додавання продукту до колекції
            Products.Add(newProduct);

            // Очищення полів після додавання
            ProductTypeComboBox.SelectedIndex = -1;
            QuantityTextBox.Clear();
            PriceTextBox.Clear();
            StockStatusComboBox.SelectedIndex = -1;

            MessageBox.Show("Товар успішно доданий!");
        }
    }

    // Клас для продукту
    public class Product
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public string StockStatus { get; set; }
    }
}
