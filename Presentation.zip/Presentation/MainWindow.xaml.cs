﻿using Presentation;
using System.Windows;

namespace Presentation
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void OpenSalesWindow(object sender, RoutedEventArgs e)
        {
            var salesWindow = new SalesWindow();
            salesWindow.Show();
        }

        private void OpenInventoryWindow(object sender, RoutedEventArgs e)
        {
            var inventoryWindow = new InventoryWindow();
            inventoryWindow.Show();
        }

        private void OpenFinanceWindow(object sender, RoutedEventArgs e)
        {
            var financeWindow = new FinanceWindow();
            financeWindow.Show();
        }

        private void OpenClientsWindow(object sender, RoutedEventArgs e)
        {
            var clientsWindow = new ClientsWindow();
            clientsWindow.Show();
        }

        private void OpenUsersWindow(object sender, RoutedEventArgs e)
        {
            var usersWindow = new UsersWindow();
            usersWindow.Show();
        }
    }
}
