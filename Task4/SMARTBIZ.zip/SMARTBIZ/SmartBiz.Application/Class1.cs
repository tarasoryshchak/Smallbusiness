﻿namespace SmartBiz.Application
{
    public class Class1
    {

    }
}
