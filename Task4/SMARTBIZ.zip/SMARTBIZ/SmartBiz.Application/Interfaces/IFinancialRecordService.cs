﻿public interface IFinancialRecordService
{
    void AddFinancialRecord(FinancialRecordDTO record);
    FinancialRecordDTO GetRecordById(int id);
    IEnumerable<FinancialRecordDTO> GetAllRecords();
    void UpdateRecord(FinancialRecordDTO record);
    void DeleteRecord(int id);
}