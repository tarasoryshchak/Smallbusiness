﻿public interface IOrderService
{
    void CreateOrder(OrderDTO order);
    OrderDTO GetOrderById(int id);
    IEnumerable<OrderDTO> GetAllOrders();
    void UpdateOrder(OrderDTO order);
    void DeleteOrder(int id);
}