﻿public interface ICustomerService
{
    void AddCustomer(CustomerDTO customer);
    CustomerDTO GetCustomerById(int id);
    IEnumerable<CustomerDTO> GetAllCustomers();
    void UpdateCustomer(CustomerDTO customer);
    void DeleteCustomer(int id);
}