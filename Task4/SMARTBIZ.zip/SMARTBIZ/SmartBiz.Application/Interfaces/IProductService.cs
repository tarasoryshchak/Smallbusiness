﻿public interface IProductService
{
    void AddProduct(ProductDTO product);
    ProductDTO GetProductById(int id);
    IEnumerable<ProductDTO> GetAllProducts();
    void UpdateProduct(ProductDTO product);
    void DeleteProduct(int id);
}