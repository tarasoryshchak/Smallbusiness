﻿public class LoyaltyProgramDTO
{
    public int Id { get; set; }
    public string ProgramName { get; set; }
    public int Points { get; set; }
    public string CustomerId { get; set; }
}