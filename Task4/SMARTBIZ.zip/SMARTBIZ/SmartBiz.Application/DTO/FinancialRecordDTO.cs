﻿public class FinancialRecordDTO
{
    public int Id { get; set; }
    public decimal Income { get; set; }
    public decimal Expenses { get; set; }
    public decimal NetProfit { get; set; }
    public DateTime RecordDate { get; set; }
}