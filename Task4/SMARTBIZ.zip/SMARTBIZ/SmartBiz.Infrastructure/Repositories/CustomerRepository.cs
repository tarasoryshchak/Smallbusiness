﻿using System.Collections.Generic;
using System.Linq;
using SmartBiz.Domain;
using SmartBiz.Application;

namespace SmartBiz.Infrastructure.Repositories
{
    public class CustomerRepository : ICustomerService
    {
        private readonly ApplicationDbContext _context;

        public CustomerRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public void AddCustomer(CustomerDTO customerDto)
        {
            var customer = new Customer
            {
                FirstName = customerDto.FirstName,
                LastName = customerDto.LastName,
                PhoneNumber = customerDto.PhoneNumber,
                Email = customerDto.Email
            };
            _context.Customers.Add(customer);
            _context.SaveChanges();
        }

        public CustomerDTO GetCustomerById(int id)
        {
            var customer = _context.Customers.Find(id);
            if (customer == null) return null;

            return new CustomerDTO
            {
                Id = customer.Id,
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                PhoneNumber = customer.PhoneNumber,
                Email = customer.Email
            };
        }

        public IEnumerable<CustomerDTO> GetAllCustomers()
        {
            return _context.Customers.Select(customer => new CustomerDTO
            {
                Id = customer.Id,
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                PhoneNumber = customer.PhoneNumber,
                Email = customer.Email
            }).ToList();
        }

        public void UpdateCustomer(CustomerDTO customerDto)
        {
            var customer = _context.Customers.Find(customerDto.Id);
            if (customer == null) return;

            customer.FirstName = customerDto.FirstName;
            customer.LastName = customerDto.LastName;
            customer.PhoneNumber = customerDto.PhoneNumber;
            customer.Email = customerDto.Email;

            _context.Customers.Update(customer);
            _context.SaveChanges();
        }

        public void DeleteCustomer(int id)
        {
            var customer = _context.Customers.Find(id);
            if (customer != null)
            {
                _context.Customers.Remove(customer);
                _context.SaveChanges();
            }
        }
    }
}