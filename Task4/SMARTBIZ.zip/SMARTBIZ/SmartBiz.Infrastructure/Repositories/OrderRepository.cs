﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using SmartBiz.Domain;
using SmartBiz.Application;

namespace SmartBiz.Infrastructure.Repositories
{
    public class OrderRepository : IOrderService
    {
        private readonly ApplicationDbContext _context;

        public OrderRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public void CreateOrder(OrderDTO orderDto)
        {
            var order = new Order
            {
                CustomerName = orderDto.CustomerName,
                OrderDate = orderDto.OrderDate,
                TotalAmount = orderDto.TotalAmount,
                Status = orderDto.Status
            };
            _context.Orders.Add(order);
            _context.SaveChanges();
        }

        public OrderDTO GetOrderById(int id)
        {
            var order = _context.Orders.Find(id);
            if (order == null) return null;

            return new OrderDTO
            {
                Id = order.Id,
                CustomerName = order.CustomerName,
                OrderDate = order.OrderDate,
                TotalAmount = order.TotalAmount,
                Status = order.Status
            };
        }

        public IEnumerable<OrderDTO> GetAllOrders()
        {
            return _context.Orders.Select(order => new OrderDTO
            {
                Id = order.Id,
                CustomerName = order.CustomerName,
                OrderDate = order.OrderDate,
                TotalAmount = order.TotalAmount,
                Status = order.Status
            }).ToList();
        }

        public void UpdateOrder(OrderDTO orderDto)
        {
            var order = _context.Orders.Find(orderDto.Id);
            if (order == null) return;

            order.CustomerName = orderDto.CustomerName;
            order.OrderDate = orderDto.OrderDate;
            order.TotalAmount = orderDto.TotalAmount;
            order.Status = orderDto.Status;

            _context.Orders.Update(order);
            _context.SaveChanges();
        }

        public void DeleteOrder(int id)
        {
            var order = _context.Orders.Find(id);
            if (order != null)
            {
                _context.Orders.Remove(order);
                _context.SaveChanges();
            }
        }
    }
}