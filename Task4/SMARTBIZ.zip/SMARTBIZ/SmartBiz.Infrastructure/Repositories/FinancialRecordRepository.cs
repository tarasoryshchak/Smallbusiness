﻿using System.Collections.Generic;
using System.Linq;
using SmartBiz.Domain;
using SmartBiz.Application;

namespace SmartBiz.Infrastructure.Repositories
{
    public class FinancialRecordRepository : IFinancialRecordService
    {
        private readonly ApplicationDbContext _context;

        public FinancialRecordRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public void AddFinancialRecord(FinancialRecordDTO recordDto)
        {
            var record = new FinancialRecord
            {
                Income = recordDto.Income,
                Expenses = recordDto.Expenses,
                RecordDate = recordDto.RecordDate
            };
            _context.FinancialRecords.Add(record);
            _context.SaveChanges();
        }

        public FinancialRecordDTO GetRecordById(int id)
        {
            var record = _context.FinancialRecords.Find(id);
            if (record == null) return null;

            return new FinancialRecordDTO
            {
                Id = record.Id,
                Income = record.Income,
                Expenses = record.Expenses,
                RecordDate = record.RecordDate
            };
        }

        public IEnumerable<FinancialRecordDTO> GetAllRecords()
        {
            return _context.FinancialRecords.Select(record => new FinancialRecordDTO
            {
                Id = record.Id,
                Income = record.Income,
                Expenses = record.Expenses,
                RecordDate = record.RecordDate
            }).ToList();
        }

        public void UpdateRecord(FinancialRecordDTO recordDto)
        {
            var record = _context.FinancialRecords.Find(recordDto.Id);
            if (record == null) return;

            record.Income = recordDto.Income;
            record.Expenses = recordDto.Expenses;

            _context.FinancialRecords.Update(record);
            _context.SaveChanges();
        }

        public void DeleteRecord(int id)
        {
            var record = _context.FinancialRecords.Find(id);
            if (record != null)
            {
                _context.FinancialRecords.Remove(record);
                _context.SaveChanges();
            }
        }
    }
}