﻿namespace SmartBiz.Infrastructure
{
    public class Class1
    {

    }
}
