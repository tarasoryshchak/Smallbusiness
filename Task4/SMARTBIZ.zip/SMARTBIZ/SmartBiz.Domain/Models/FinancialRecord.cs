﻿public class FinancialRecord
{
    public int Id { get; set; }
    public decimal Income { get; set; }
    public decimal Expenses { get; set; }
    public decimal NetProfit => Income - Expenses; // Обчислення чистого прибутку
    public DateTime RecordDate { get; set; } = DateTime.Now; // Дата запису
}