﻿namespace SmartBiz.Domain
{
    public class Class1
    {

    }
}
